class Question {
  final String id;
  final String question;
  final Map<String, List<String>> options; // เปลี่ยนเป็น Map
  final String type; // 'radio' หรือ 'checkbox'

  Question({
    required this.id,
    required this.question,
    required this.options,
    required this.type,
  });

  factory Question.fromJson(Map<String, dynamic> json) {
    return Question(
      id: json['_id'] ?? '', // ให้ค่าเริ่มต้นเป็นสตริงว่างหาก id เป็น null
      question: json['question'] ?? 'No question provided', // ข้อความคำถามเริ่มต้น
      options: json['options'] != null
          ? Map<String, List<String>>.from(json['options'].map((key, value) => MapEntry(key, List<String>.from(value))))
          : {}, // แปลงเป็น Map หาก options ไม่เป็น null
      type: json['type'] ?? 'radio', // ค่าเริ่มต้นเป็น 'radio' หาก type เป็น null
    );
  }
}

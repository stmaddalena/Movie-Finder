import 'package:flutter/material.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final String searchQuery;
  final String selectedGenre;
  final String? selectedType;
  final List<String> genres;
  final ValueChanged<String?> onGenreSelected;
  final ValueChanged<String?> onTypeSelected;
  final ValueChanged<String> onSearchChanged;

  // Define the color variable
  final Color borderColor = Colors.grey[50]!;

  CustomAppBar({
    required this.title,
    required this.searchQuery,
    required this.selectedGenre,
    required this.selectedType,
    required this.genres,
    required this.onGenreSelected,
    required this.onTypeSelected,
    required this.onSearchChanged,
  });

void _showGenreDialog(BuildContext context) {
  final ScrollController scrollController = ScrollController();
  final double itemHeight = 50.0; // Height of each ListTile
  final double dialogHeight = 450.0; // Height of the AlertDialog

  showDialog(
    context: context,
    barrierColor: Color.fromARGB(204, 0, 0, 0), // Dark background color
    builder: (BuildContext context) {
      return Center(
        child: Container(
          constraints: BoxConstraints(
            maxHeight: dialogHeight,
            maxWidth: MediaQuery.of(context).size.width * 0.8, // Adjust width if needed
          ),
          child: AlertDialog(
            backgroundColor: Color.fromARGB(230, 16, 16, 16), // Background color of the dialog
            contentPadding: EdgeInsets.zero, // Remove default padding
            content: NotificationListener<ScrollNotification>(
              onNotification: (ScrollNotification notification) {
                if (notification is ScrollUpdateNotification) {
                  // Trigger a rebuild when scrolling
                  (context as Element).markNeedsBuild();
                }
                return true;
              },
              child: SingleChildScrollView(
                controller: scrollController,
                child: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: genres.asMap().entries.map((MapEntry<int, String> entry) {
                        int index = entry.key;
                        String genre = entry.value;

                        // Calculate the opacity based on the position in the viewport
                        double itemOffset = index * itemHeight;
                        double scrollOffset = scrollController.hasClients ? scrollController.offset : 0.0;
                        double viewportHeight = dialogHeight;
                        double maxDistance = viewportHeight;
                        double itemPosition = itemOffset - scrollOffset;
                        double opacity = 1.0 - (itemPosition / maxDistance);
                        opacity = opacity.clamp(0.0, 1.0); // Ensure opacity is between 0.0 and 1.0

                        return ListTile(
                          title: Center(
                            child: Text(
                              genre,
                              style: TextStyle(
                                color: Colors.grey[50]?.withOpacity(opacity), // Text color with changing opacity
                                fontSize: 22.0, // Adjust font size if needed
                              ),
                            ),
                          ),
                          onTap: () {
                            Navigator.pop(context);
                            onGenreSelected(genre);
                          },
                        );
                      }).toList(),
                    );
                  },
                ),
              ),
            ),
          ),
        ),
      );
    },
  );
}





  void _showSearchDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Align(
          alignment: Alignment.topCenter,
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            margin: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
            color: Colors.transparent, // Background color of the dialog
            child: Material(
              child: Container(
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 16, 16, 16), // Background color of the text field
                ),
                child: TextField(
                  autofocus: true,
                  onChanged: onSearchChanged,
                  style: TextStyle(
                    color: Colors.grey[50], // Text color inside the text field
                  ),
                  textAlign: TextAlign.left, // Align text to the left
                  textAlignVertical: TextAlignVertical.center, // Vertically center the text
                  decoration: InputDecoration(
                    hintText: 'Search...',
                    hintStyle: TextStyle(color: Colors.grey[50],fontWeight: FontWeight.w300), // Hint text color
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 16.0), // Padding inside the text field
                    suffixIcon: IconButton(
                      icon: Icon(Icons.close, color: Colors.grey[50]), // Icon color
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
Widget build(BuildContext context) {
  return AppBar(
    leading: IconButton(
      icon: Icon(Icons.arrow_back, color: Colors.grey[50]),
      onPressed: () {
        Navigator.pop(context);
      },
    ),
    title: Text(
      title,
      style: TextStyle(
        color: Colors.grey[50],
        fontWeight: FontWeight.bold,
      ),
    ),
    backgroundColor: Color.fromARGB(255, 16, 16, 16),
    actions: [
      IconButton(
        icon: Icon(Icons.search, color: Colors.grey[50]),
        onPressed: () => _showSearchDialog(context),
      ),
    ],
    bottom: PreferredSize(
      preferredSize: Size.fromHeight(140), // Increase the height of the AppBar
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0).copyWith(bottom: 14.0), // Add bottom padding here
        child: Row(
          children: [
            if (selectedType == null) ...[
              TextButton(
                onPressed: () {
                  onTypeSelected('Movie');
                },
                style: TextButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                    side: BorderSide(color: borderColor, width: 0.6), // ทำให้ขอบบางลง
                  ),
                  backgroundColor: Colors.transparent,
                ),
                child: Text(
                  'Movie',
                  style: TextStyle(
                    color: selectedType == 'Movie' ? Colors.red : borderColor,
                    fontWeight: FontWeight.w300, // ทำให้ตัวหนังสือบางลง
                  ),
                ),
              ),
              SizedBox(width: 8.0),
              TextButton(
                onPressed: () {
                  onTypeSelected('Series');
                },
                style: TextButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                    side: BorderSide(color: borderColor, width: 0.6), // ทำให้ขอบบางลง
                  ),
                  backgroundColor: Colors.transparent,
                ),
                child: Text(
                  'Series',
                  style: TextStyle(
                    color: selectedType == 'Series' ? Colors.red : borderColor,
                    fontWeight: FontWeight.w300, // ทำให้ตัวหนังสือบางลง
                  ),
                ),
              ),
            ] else ...[
              TextButton.icon(
                onPressed: () => onTypeSelected(null),
                icon: Icon(Icons.cancel, color: borderColor),
                label: Text(
                  selectedType!,
                  style: TextStyle(color: borderColor, fontWeight: FontWeight.w300), // ทำให้ตัวหนังสือบางลง
                ),
                style: TextButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                    side: BorderSide(color: borderColor, width: 0.6), // ทำให้ขอบบางลง
                  ),
                  backgroundColor: Colors.transparent,
                ),
              ),
            ],
            SizedBox(width: 8.0),
            if (selectedGenre != 'All') ...[
              TextButton.icon(
                onPressed: () {
                  onGenreSelected('All'); // Reset only genre
                },
                icon: Icon(Icons.cancel, color: borderColor),
                label: Text(
                  selectedGenre,
                  style: TextStyle(color: borderColor, fontWeight: FontWeight.w300), // ทำให้ตัวหนังสือบางลง
                ),
                style: TextButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                    side: BorderSide(color: borderColor, width: 0.6), // ทำให้ขอบบางลง
                  ),
                  backgroundColor: Colors.transparent,
                ),
              ),
            ] else ...[
              TextButton(
                onPressed: () => _showGenreDialog(context),
                style: TextButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                    side: BorderSide(color: borderColor, width: 0.6), // ทำให้ขอบบางลง
                  ),
                  backgroundColor: Colors.transparent,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Genres',
                      style: TextStyle(color: borderColor, fontWeight: FontWeight.w300), // ทำให้ตัวหนังสือบางลง
                    ),
                    SizedBox(width: 4.0),
                    Icon(
                      Icons.arrow_drop_down,
                      color: borderColor,
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    ),
  );
}



  @override
  Size get preferredSize => Size.fromHeight(120); // Increase the height of the AppBar
}

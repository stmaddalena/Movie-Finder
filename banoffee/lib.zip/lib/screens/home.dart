import 'package:flutter/material.dart';
import 'entertainment.dart';
import 'question.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => EntertainmentScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                minimumSize: Size(200, 70), // กำหนดขนาดปุ่ม
                textStyle: TextStyle(fontSize: 20), // กำหนดขนาดตัวอักษร
              ),
              child: Text('Go to Entertainment'),
            ),
            SizedBox(height: 20), // เพิ่มช่องว่างระหว่างปุ่ม
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => QuestionScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                minimumSize: Size(200, 70), // กำหนดขนาดปุ่ม
                textStyle: TextStyle(fontSize: 20), // กำหนดขนาดตัวอักษร
              ),
              child: Text('Go to Questions'),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import '../models/entertainment.dart'; // Assuming this is where Entertainment model is

class EntertainmentDetailScreen extends StatelessWidget {
  final Entertainment entertainment;

  EntertainmentDetailScreen({required this.entertainment});

  void _showReviewsDialog(
      BuildContext context, String title, List<String> reviews) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            title,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor:
              Color.fromARGB(255, 254, 255, 254), // เปลี่ยนสีพื้นหลังของ dialog
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0), // กำหนดขอบมนของ dialog
          ),
          content: SingleChildScrollView(
            child: ListBody(
              children: reviews.map((review) {
                return Text(
                  '["$review"]\n',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                );
              }).toList(),
            ),
          ),
          actions: <Widget>[
            Center(
              child: SizedBox(
                height: 35, // ความสูงของปุ่ม
                width: 35, // ความกว้างของปุ่ม
                child: Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.black87, // สีพื้นหลังของวงกลม
                      ),
                    ),
                    IconButton(
                      icon:
                          Icon(Icons.close, color: Colors.white), // สีของไอคอน
                      iconSize: 20, // ขนาดของไอคอน
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: const Color.fromARGB(255, 20, 20, 20),
          leading: IconButton(
            icon: Icon(Icons.arrow_back,
                color: Colors.grey[50]), // Change the color to white
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        backgroundColor: Color.fromARGB(255, 20, 20, 20),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8.0),
                    child: Image.network(
                      entertainment.poster,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 32.0),
                Text(
                  entertainment.title,
                  style: TextStyle(
                      fontSize: 24,
                      color: Colors.grey[50],
                      fontWeight: FontWeight.bold),
                ),

                SizedBox(height: 8.0),
                Row(
                  children: [
                    Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                            text: '[ ',
                            style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey[50],
                                fontWeight: FontWeight.w300),
                          ),
                          TextSpan(
                            text: entertainment.rating,
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey[50],
                            ),
                          ),
                          TextSpan(
                            text: ' ]',
                            style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey[50],
                                fontWeight: FontWeight.w300),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                        width: 12.0), // เว้นระยะห่างระหว่าง rating และ genres
                    Text(
                      entertainment.genres.join(' • '),
                      style: TextStyle(fontSize: 16, color: Colors.blue[200]),
                    ),
                  ],
                ),
                SizedBox(height: 8.0),
                Text(entertainment.synopsis,
                    style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[350],
                        fontWeight: FontWeight.w300)),
                // Add more details as needed
                SizedBox(height: 32.0),

                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: 'Where to watch :  ',
                        style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[50],
                            fontWeight: FontWeight.normal),
                      ),
                      TextSpan(
                        text: entertainment.streaming.join(' • '),
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[50],
                            fontWeight: FontWeight.w300),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 8.0),
                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: 'Duration :  ',
                        style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[50],
                            fontWeight: FontWeight.normal),
                      ),
                      TextSpan(
                        text: entertainment.duration,
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[50],
                            fontWeight: FontWeight.w300),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 8.0),
                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: 'Release date :  ',
                        style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[50],
                            fontWeight: FontWeight.normal),
                      ),
                      TextSpan(
                        text: entertainment.releaseDate,
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[50],
                            fontWeight: FontWeight.w300),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 8.0),
                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: 'Original language :  ',
                        style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[50],
                            fontWeight: FontWeight.normal),
                      ),
                      TextSpan(
                        text: entertainment.originalLanguage,
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[50],
                            fontWeight: FontWeight.w300),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 8.0),
                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: 'Production co :  ',
                        style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[50],
                            fontWeight: FontWeight.normal),
                      ),
                      TextSpan(
                        text: entertainment.productionCos.join(' • '),
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[50],
                            fontWeight: FontWeight.w300),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 8.0),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 24.0),
                    Container(
                      padding: EdgeInsets.fromLTRB(12.0, 12.0, 12.0, 0),
                      decoration: BoxDecoration(
                        color:
                            Colors.white.withOpacity(0.1), // สีพื้นหลังของกรอบ
                        borderRadius:
                            BorderRadius.circular(10.0), // ขอบมนของกรอบ
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 6),
                          Text(
                            'Stars',
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.blue[200],
                              fontWeight: FontWeight.normal,
                            ),
                          ),
                          SizedBox(
                              height:
                                  16.0), // ระยะห่างระหว่างหัวข้อและ GridView ของ Stars
                          GridView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 3, // 3 ช่องต่อ 1 แถว
                              childAspectRatio:
                                  2 / 3, // กำหนดอัตราส่วนให้เหมาะสม
                            ),
                            itemCount: entertainment.cast.length,
                            itemBuilder: (context, index) {
                              final castMember = entertainment.cast[index];
                              return Column(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(8.0),
                                    child: Image.network(
                                      castMember.photo,
                                      width: 80,
                                      height: 120,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  SizedBox(height: 8.0),
                                  Text(
                                    castMember.name,
                                    style: TextStyle(
                                      fontSize: 13,
                                      color: Colors.grey[50],
                                      fontWeight: FontWeight.w300,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                        height:
                            8.0), // ระยะห่างระหว่างส่วน Stars และ Directed by
                    Container(
                      padding: EdgeInsets.fromLTRB(12.0, 12.0, 12.0, 0),
                      decoration: BoxDecoration(
                        color:
                            Colors.white.withOpacity(0.1), // สีพื้นหลังของกรอบ
                        borderRadius:
                            BorderRadius.circular(8.0), // ขอบมนของกรอบ
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 6),
                          Text(
                            'Directed by',
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.blue[200],
                              fontWeight: FontWeight.normal,
                            ),
                          ),
                          SizedBox(
                              height:
                                  16.0), // ระยะห่างระหว่างหัวข้อและ GridView ของ Directed by
                          GridView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 3, // 3 ช่องต่อ 1 แถว
                              childAspectRatio:
                                  2 / 3, // กำหนดอัตราส่วนให้เหมาะสม
                            ),
                            itemCount: entertainment.directors.length,
                            itemBuilder: (context, index) {
                              final directorsMember =
                                  entertainment.directors[index];
                              return Column(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(8.0),
                                    child: Image.network(
                                      directorsMember.photo,
                                      width: 80,
                                      height: 120,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  SizedBox(height: 8.0),
                                  Text(
                                    directorsMember.name,
                                    style: TextStyle(
                                      fontSize: 13,
                                      color: Colors.grey[50],
                                      fontWeight: FontWeight.w300,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 32.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          _showReviewsDialog(
                            context,
                            'Audience Reviews',
                            entertainment.reviews.audience,
                          );
                        },
                        child: Container(
                          padding: EdgeInsets.all(8.0),
                          decoration: BoxDecoration(
                             color: Colors.white.withOpacity(0.1),
                            border: Border.all(
                                color: Colors.white.withOpacity(0), width: 0.8),
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          child: Center(
                            // จัดตำแหน่งข้อความให้อยู่ตรงกลาง
                            child: Text(
                              'Audience',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.blue[200],
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 8.0), // เพิ่มระยะห่างเล็กน้อยระหว่างปุ่ม
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          _showReviewsDialog(
                            context,
                            'Critic Reviews',
                            entertainment.reviews.critic,
                          );
                        },
                        child: Container(
                          padding: EdgeInsets.all(8.0),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.1),
                            border: Border.all(
                                color: Colors.white.withOpacity(0), width: 0.8),
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          child: Center(
                            // จัดตำแหน่งข้อความให้อยู่ตรงกลาง
                            child: Text(
                              'Critic',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.blue[200],
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 32.0),
              ],
            ),
          ),
        ));
  }
}

import 'package:flutter/material.dart';
import 'dart:math'; // Import for Random
import '../models/entertainment.dart';
import 'detail.dart';
import 'home.dart'; // Import your HomeScreen file

class ResultScreen extends StatefulWidget {
  final String selectedType;
  final List<String> selectedGenres;
  final String selectedRating;
  final List<String> selectedStreaming;
  final List<Entertainment> entertainmentList;
  final String searchQuery;

  ResultScreen({
    required this.selectedType,
    required this.selectedGenres,
    required this.selectedRating,
    required this.selectedStreaming,
    required this.entertainmentList,
    required this.searchQuery,
  });

  @override
  _ResultScreenState createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  late List<Entertainment> filteredEntertainmentList;
  Entertainment? randomEntertainment;
  List<Entertainment> previouslyShown = []; // Track previously shown items

  @override
  void initState() {
    super.initState();
    filteredEntertainmentList = _filterEntertainmentList();
    _getRandomEntertainment();
  }

  List<Entertainment> _filterEntertainmentList() {
    final genresList =
        widget.selectedGenres.map((genre) => genre.trim()).toSet();
    final streamingList =
        widget.selectedStreaming.map((service) => service.trim()).toSet();

    return widget.entertainmentList.where((item) {
      final typeMatch =
          widget.selectedType.isEmpty || item.type == widget.selectedType;

      final genresMatch = genresList.isEmpty ||
          genresList.any((selectedGenre) {
            return item.genres.contains(selectedGenre);
          });

      final streamingMatch = streamingList.isEmpty ||
          item.streaming.any((stream) => streamingList.contains(stream));

      final ratingMatch =
          widget.selectedRating.isEmpty || item.rating == widget.selectedRating;
      final searchMatch = widget.searchQuery.isEmpty ||
          item.title.toLowerCase().contains(widget.searchQuery.toLowerCase()) ||
          item.cast.any((member) => member.name
              .toLowerCase()
              .contains(widget.searchQuery.toLowerCase()));

      return typeMatch &&
          genresMatch &&
          ratingMatch &&
          streamingMatch &&
          searchMatch;
    }).toList();
  }

  void _getRandomEntertainment() {
    if (filteredEntertainmentList.isNotEmpty) {
      final random = Random();
      List<Entertainment> availableItems = filteredEntertainmentList
          .where((item) => !previouslyShown.contains(item))
          .toList();

      if (availableItems.isEmpty) {
        previouslyShown.clear();
        availableItems = List.from(filteredEntertainmentList);
      }

      randomEntertainment =
          availableItems[random.nextInt(availableItems.length)];
      previouslyShown.add(randomEntertainment!);
    } else {
      randomEntertainment = null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 16, 16, 16), // Change background color to black
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 16, 16, 16), // Change AppBar color to black
        iconTheme: IconThemeData(color: Colors.grey[50]), // Change back arrow color to white
        actions: [
Padding(
  padding: const EdgeInsets.only(right: 8.0, top:8), // Add padding on the right
  child: TextButton(
    onPressed: () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => HomeScreen()), // Navigate to HomeScreen
      );
    },
    child: Text(
      'Finish',
      style: TextStyle(
        color: Colors.blue[200], // Set text color
        fontSize: 16, // Set font size to 16
      ),
    ),
  ),
),

        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              if (randomEntertainment != null) ...[
                Text(
                  randomEntertainment!.title,
                  style: TextStyle(
                      color: Colors.grey[50],
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 28.0),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => EntertainmentDetailScreen(
                          entertainment:
                              randomEntertainment!,
                        ),
                      ),
                    );
                  },
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(5.0),
                    child: Image.network(
                      randomEntertainment!.poster,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _getRandomEntertainment(); // Get a new random item when the button is pressed
                    });
                  },
                  child: Icon(
                    Icons.refresh,
                    color: Colors.grey[50],
                    size: 32.0,
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color.fromARGB(255, 16, 16, 16),
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(0),
                    ),
                  ).copyWith(
                    splashFactory: NoSplash.splashFactory,
                    shadowColor: MaterialStateProperty.all(Colors.transparent),
                  ),
                ),
              ],
if (randomEntertainment == null) ...[
  Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          '😢', // Sad emoji
          style: TextStyle(
            fontSize: 48.0, // Size of the emoji
          ),
        ),
        SizedBox(height: 8.0), // Space between the emoji and the text
        Text(
          "There's nothing interesting to recommend at this time.",
          style: TextStyle(color: Colors.grey[50]),
        ),
      ],
    ),
  ),
],


            ],
          ),
        ),
      ),
    );
  }
}

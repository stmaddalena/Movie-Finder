import 'package:flutter/material.dart';
import '../services.dart';
import '../models/question.dart';
import 'result_screen.dart';
import '../models/entertainment.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: QuestionScreen(),
    );
  }
}

class QuestionScreen extends StatefulWidget {
  @override
  _QuestionScreenState createState() => _QuestionScreenState();
}

class _QuestionScreenState extends State<QuestionScreen> {
  late Future<List<Question>> futureQuestions;
  late Future<List<Entertainment>> futureEntertainment;
  int currentQuestionIndex = 0;

  // Maps to store selections
  Map<int, String?> radioSelections = {};
  Map<int, List<String>> checkboxSelections = {};

  @override
  void initState() {
    super.initState();
    futureQuestions = QuestionService().fetchQuestion();
    futureEntertainment = EntertainmentService().fetchEntertainment();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 16, 16, 16), // เปลี่ยนสีพื้นหลัง
      body: FutureBuilder<List<Question>>(
        future: futureQuestions,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}', style: TextStyle(color: Colors.red)));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No questions found.', style: TextStyle(color: Colors.grey[50])));
          } else {
            final questions = snapshot.data!;
            final currentQuestion = questions[currentQuestionIndex];
            return buildQuestionCard(currentQuestion, questions.length);
          }
        },
      ),
    );
  }

 Widget buildQuestionCard(Question question, int totalQuestions) {
  return Padding(
    padding: EdgeInsets.all(16.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 70.0), // เพิ่มระยะขอบด้านบนสุด
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  question.question,
                  style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold, color: Colors.grey[50]),
                ),
                SizedBox(height: 20.0),
if (question.type == 'radio')
  ...question.options.entries.map((entry) {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1), // เปลี่ยนสีพื้นหลังของตัวเลือก
            borderRadius: BorderRadius.circular(4.0), // กำหนดความโค้งของกรอบ
          ),
          child: RadioListTile<String>(
            title: Text(entry.key, style: TextStyle(fontSize: 16.0, color: Colors.grey[50])),
            value: entry.value.first,
            groupValue: radioSelections[currentQuestionIndex],
            activeColor: Colors.blue[200], // เปลี่ยนสีไอคอนที่เลือกเป็นสีขาว
            onChanged: (value) {
              setState(() {
                radioSelections[currentQuestionIndex] = value;
              });
            },
          ),
        ),
        SizedBox(height: 10.0), // เพิ่มระยะห่างระหว่างตัวเลือก
      ],
    );
  }).toList(),




if (question.type == 'checkbox')
  ...question.options.entries.map((entry) {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1), // เปลี่ยนสีพื้นหลังของตัวเลือก
            borderRadius: BorderRadius.circular(4.0), // กำหนดความโค้งของกรอบ
          ),
          child: CheckboxListTile(
            title: Text(entry.key, style: TextStyle(fontSize: 16.0, color: Colors.grey[50])),
            value: checkboxSelections[currentQuestionIndex]?.any(
                    (selectedValue) => entry.value.contains(selectedValue)) ?? false,
            activeColor: Colors.blue[200], // เปลี่ยนสีไอคอนที่เลือกเป็นสีขาว
            onChanged: (bool? value) {
              setState(() {
                if (value == true) {
                  checkboxSelections.putIfAbsent(currentQuestionIndex, () => []).addAll(entry.value);
                } else {
                  checkboxSelections[currentQuestionIndex]?.removeWhere(
                      (selectedValue) => entry.value.contains(selectedValue));
                }
              });
            },
          ),
        ),
        SizedBox(height: 10.0), // เพิ่มระยะห่างระหว่างตัวเลือก
      ],
    );
  }).toList(),




              ],
            ),
          ),
        ),
        SizedBox(height: 10.0),
    Row(
  mainAxisAlignment: MainAxisAlignment.spaceBetween,
  children: [
    if (currentQuestionIndex == 0)
      Expanded(
        child: Padding(
          padding: const EdgeInsets.only(right: 4.0), // เพิ่มระยะห่างทางขวาของปุ่ม Cancel
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(0.1), // เปลี่ยนสีพื้นหลังเป็นสีแดง
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4), // กำหนดความโค้งของมุม
              ),
            ).copyWith(
              splashFactory: NoSplash.splashFactory, // Disable ripple effect
              shadowColor: MaterialStateProperty.all(Colors.transparent), // Remove shadow color
            ),
            onPressed: () {
              Navigator.pop(context); // กลับไปที่หน้า Home
            },
            child: Text(
              'Cancel',
              style: TextStyle(color: Colors.grey[50], fontSize: 14), // ตัวอักษรสีขาว ขนาด 16
            ),
          ),
        ),
      ),
    if (currentQuestionIndex > 0)
      Expanded(
        child: Padding(
          padding: const EdgeInsets.only(right: 4.0), // เพิ่มระยะห่างทางขวาของปุ่ม Previous
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(0.1), // เปลี่ยนสีพื้นหลังเป็นสีแดง
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4), // กำหนดความโค้งของมุม
              ),
            ).copyWith(
              splashFactory: NoSplash.splashFactory, // Disable ripple effect
              shadowColor: MaterialStateProperty.all(Colors.transparent), // Remove shadow color
            ),
            onPressed: () {
              setState(() {
                currentQuestionIndex--;
              });
            },
            child: Text(
              'Previous',
              style: TextStyle(color: Colors.grey[50], fontSize: 14), // ตัวอักษรสีขาว ขนาด 16
            ),
          ),
        ),
      ),
    Expanded(
      child: Padding(
        padding: const EdgeInsets.only(left: 4.0), // เพิ่มระยะห่างทางซ้ายของปุ่ม Next/Finish
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue[200], // เปลี่ยนสีพื้นหลังเป็นสีเขียว
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4), // กำหนดความโค้งของมุม
            ),
          ).copyWith(
            splashFactory: NoSplash.splashFactory, // Disable ripple effect
            shadowColor: MaterialStateProperty.all(Colors.transparent), // Remove shadow color
          ),
          onPressed: () {
            bool canProceed = false;

            // ตรวจสอบเงื่อนไขสำหรับ radio
            if (question.type == 'radio') {
              canProceed = radioSelections[currentQuestionIndex] != null;
            }
            // ตรวจสอบเงื่อนไขสำหรับ checkbox
            else if (question.type == 'checkbox') {
              canProceed = checkboxSelections[currentQuestionIndex]?.isNotEmpty ?? false;
            }

            if (canProceed) {
              if (currentQuestionIndex < totalQuestions - 1) {
                setState(() {
                  currentQuestionIndex++;
                });
              } else {
                futureEntertainment.then((entertainmentList) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultScreen(
                        searchQuery: '',
                        selectedType: radioSelections[0] ?? '',
                        selectedGenres: checkboxSelections[1] ?? [],
                        selectedRating: radioSelections[2] ?? '',
                        selectedStreaming: checkboxSelections[3] ?? [],
                        entertainmentList: entertainmentList,
                      ),
                    ),
                  );
                }).catchError((error) {
                  print('Error fetching entertainment data: $error');
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error loading entertainment data.')),
                  );
                });
              }
            } else {
              // แสดงข้อความเตือนถ้าไม่มีการเลือก
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Container(
                    padding: EdgeInsets.symmetric(vertical: 10.0), // เพิ่มขนาดความสูง
                    child: Text(
                      'Please select an option before continuing.',
                      textAlign: TextAlign.center, // จัดข้อความไว้ตรงกลาง
                      style: TextStyle(fontSize: 14), // เพิ่มขนาดข้อความ
                    ),
                  ),
                  backgroundColor: Colors.red, // เปลี่ยนสีพื้นหลัง
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(0), // ทำให้ snackbar ไม่มีมุมโค้งมน
                  ),
                  duration: Duration(milliseconds: 1864), // แสดงเป็นเวลา 0.5 วินาที
                ),
              );
            }
          },
          child: Text(
            currentQuestionIndex < totalQuestions - 1 ? 'Next' : 'Finish',
            style: TextStyle(color: Color.fromARGB(255, 16, 16, 16), fontSize: 14), // ตัวอักษรสีขาว ขนาด 16
          ),
        ),
      ),
    ),
  ],
),



      ],
    ),
  );
}

}

import 'package:flutter/material.dart';
import '../services.dart';
import '../models/entertainment.dart';
import 'detail.dart';
import '../widgets/appbar.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: EntertainmentScreen(),
    );
  }
}

class EntertainmentScreen extends StatefulWidget {
  @override
  _EntertainmentScreenState createState() => _EntertainmentScreenState();
}

class _EntertainmentScreenState extends State<EntertainmentScreen> {
  late Future<List<Entertainment>> futureEntertainment;
  List<Entertainment> allEntertainment = [];
  List<Entertainment> filteredEntertainment = [];
  String searchQuery = '';
  String selectedGenre = 'All'; // ตั้งค่าเริ่มต้นเป็น 'All'
  String? selectedType; // ใช้ String? เพื่อให้รองรับการเลือก

  final List<String> genres = [
    'Action',
    'Adventure',
    'Animation',
    'Biography',
    'Comedy',
    'Crime',
    'Drama',
    'Family',
    'Fantasy',
    'History',
    'Horror',
    'Music',
    'Musical',
    'Mystery',
    'Romance',
    'Sci-Fi',
    'Sport',
    'Thriller',
    'War',
    'Western'
  ];

  @override
  void initState() {
    super.initState();
    futureEntertainment = EntertainmentService().fetchEntertainment();
    futureEntertainment.then((entertainments) {
      setState(() {
        allEntertainment = entertainments;
        filteredEntertainment = entertainments;
      });
    });
  }

  void _filterEntertainment(String query) {
    setState(() {
      searchQuery = query;
      filteredEntertainment = allEntertainment
          .where((entertainment) =>
              (entertainment.title
                      .toLowerCase()
                      .contains(query.toLowerCase()) ||
                  entertainment.cast.any((member) => member.name
                      .toLowerCase()
                      .contains(query.toLowerCase()))) &&
              (selectedGenre == 'All' ||
                  entertainment.genres.contains(selectedGenre)) &&
              (selectedType == null || entertainment.type == selectedType))
          .toList();
    });
  }

  void _onGenreSelected(String? genre) {
    setState(() {
      selectedGenre = genre ?? 'All'; // รีเซ็ต genre เป็น 'All'
      _filterEntertainment(searchQuery);
    });
  }

  void _onTypeSelected(String? type) {
    setState(() {
      selectedType = type;
      _filterEntertainment(searchQuery);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'ENTERTAINMENT',
        searchQuery: searchQuery,
        selectedGenre: selectedGenre,
        selectedType: selectedType,
        genres: genres,
        onGenreSelected: _onGenreSelected,
        onTypeSelected: _onTypeSelected,
        onSearchChanged: _filterEntertainment,
      ),
      backgroundColor: Color.fromARGB(255, 16, 16, 16),
      body: filteredEntertainment.isEmpty
          ? Center(child: CircularProgressIndicator())
          : GridView.builder(
              padding: const EdgeInsets.all(8.0),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 8,
                mainAxisSpacing: 24,
                childAspectRatio: 0.7,
              ),
              itemCount: filteredEntertainment.length,
              itemBuilder: (context, index) {
                Entertainment entertainment = filteredEntertainment[index];
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => EntertainmentDetailScreen(
                            entertainment: entertainment),
                      ),
                    );
                  },
                  child: Column(
                    children: [
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(5.0),
                          child: Image.network(
                            entertainment.poster,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}

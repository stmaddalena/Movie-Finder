import 'dart:convert';
import 'package:http/http.dart' as http;
import './models/entertainment.dart';
import './models/question.dart';

class EntertainmentService {
  Future<List<Entertainment>> fetchEntertainment() async {
    final response =
        await http.get(Uri.parse('http://10.0.2.2:3000/entertainment'));
    if (response.statusCode == 200) {
      List<dynamic> jsonData = json.decode(response.body);
      return jsonData.map((json) => Entertainment.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load');
    }
  }
}

class QuestionService {
  Future<List<Question>> fetchQuestion() async {
    final response =
        await http.get(Uri.parse('http://10.0.2.2:3000/questions'));
    if (response.statusCode == 200) {
      List<dynamic> jsonData = json.decode(response.body);
      return jsonData.map((json) => Question.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load');
    }
  }
}
